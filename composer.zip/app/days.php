<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class days extends Model
{
    protected $fillable = ['name'];
}
