<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class menuCat extends Model
{
    protected $fillable = ['name'];
}
