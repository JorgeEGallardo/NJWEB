<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class catalogos extends Model
{
    protected $fillable = ['description' . 'menu', 'recipes'];
}
