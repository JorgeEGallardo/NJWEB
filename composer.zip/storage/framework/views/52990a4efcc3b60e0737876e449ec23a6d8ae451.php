<div class="section text-center">
        <h2 class="title">Pacientes </h2>
        <a href="<?php echo e(url('/patient/add')); ?>" class="btn btn-primary btn-round">
                    <i class="material-icons">add_box</i> Añadir nuevo paciente
        </a>
        <div class="team">
            <div class="row">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nombre de usuario</th>
                            <th>Nombre completo</th>
                            <th class="text-right">Acciones</th>
                        </tr>
                    </thead>
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>

                            <td><?php echo e($patient->username); ?></td>
                            <td><?php echo e($patient->fullname); ?></td>
                            <td class="td-actions text-right">
                                <a href="<?php echo e(url('/patient/'.$patient->id.'/view')); ?>" rel="tooltip" title="Ver" class="btn btn-success">
                                    <i class="material-icons">info</i>
                                </a>
                                <a href="<?php echo e(url('/patient/'.$patient->id.'/agregar')); ?>" rel="tooltip" title="Cargar archivos del paciente " class="btn btn-success">
                                    <i class="material-icons">cloud_upload</i>
                                </a>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/patients/table_sub.blade.php ENDPATH**/ ?>