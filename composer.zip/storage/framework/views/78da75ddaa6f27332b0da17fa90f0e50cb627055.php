<?php $__env->startSection('body-class','profile-page sidebar-collapse'); ?>
<?php $__env->startSection('title', 'Pacientes'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header header-filter" data-parallax="true" style="background-image: url('/img/cover-index.png')">

  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h1 class="title">Adara wellness & spa</h1>
        <h4>Sistema de administracion de WellnessPal</h4>
      </div>
    </div>
  </div>

</div>
<div class="main main-raised">
  <div class="container">
    <div class="section text-center">
      <h2 class="title">Rutinas</h2>
      <?php if(isset($routines[0])): ?>
      <form method="post" action="<?php echo e(url('/rutinas/patient/'.$routines[0]->patient_id.'/delete')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>



                        <button type="submit" rel="tooltip" title="eliminar rutina" class="btn btn-danger">
                            <i class="material-icons">close</i>Eliminar registros

                        </button>
                      </form>
                      <?php endif; ?>
      <div class="team">
        <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th>Ejercicio</th>
                    <th>Porcion</th>
                    <th>Paciente</th>
                    <th>Día</th>
                    <th>Tipo</th>
                    <th class="text-right">Acciones</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $routines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $routine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($routine->name); ?></td>
                    <td><?php echo e($routine->series); ?></td>
                    <td><?php echo e($routine->repetitions); ?></td>
                    <td><?php echo e($routine->intensity); ?></td>
                    <td><?php echo e($routine->link); ?></td>
                    <td><?php echo e($routine->days); ?></td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
      </div>
    </div>
  </div>
    <a href ="<?php echo e(url('/rutinas')); ?>"class="btn btn-success btn-round">
      <i class="material-icons">keyboard_return</i> Regresar
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/routines/routines.blade.php ENDPATH**/ ?>