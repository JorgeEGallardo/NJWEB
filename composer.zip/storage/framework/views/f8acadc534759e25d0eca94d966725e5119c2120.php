<?php $__env->startSection('title', 'Pacientes'); ?>
<?php $__env->startSection('body-class','profile-page'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header header-filter" data-parallax="true" style="background-image: url('/img/cover-index.png')">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1 class="title">Adara wellness & spa</h1>
                <h4>Sistema de administracion de WellnessPal</h4>
            </div>
        </div>
    </div>
</div>
<div class="main main-raised">
    <div class="container">
        
        <div class="text-center">
        <br>
            
            <h2 class="title">Pacientes </h2>
            <a href="<?php echo e(url('/patient/add')); ?>" class="btn btn-success btn-round">
                        <i class="material-icons">add_box</i> Añadir nuevo paciente
            </a>
            <div class="team">
                <input type="text" class="form-control col-md-12" id="str" placeholder="Buscar">
                <button type="button" onclick="search()" class="btn btn-success">Buscar</button>
                <div id="table">

                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nombre de usuario</th>
                                <th>Nombre completo</th>
                                <th class="text-right">Acciones</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>

                                <td><?php echo e($patient->username); ?></td>
                                <td><?php echo e($patient->fullname); ?></td>
                                <td class="td-actions text-right">
                                    <a href="<?php echo e(url('/patient/'.$patient->id.'/view')); ?>" rel="tooltip" title="Ver" class="btn btn-success">
                                        <i class="material-icons">info</i>
                                    </a>
                                    <a href="<?php echo e(url('/patient/'.$patient->id.'/agregar')); ?>" rel="tooltip" title="Cargar archivos del paciente " class="btn btn-success">
                                        <i class="material-icons">cloud_upload</i>
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-success btn-round">
                        <i class="material-icons">keyboard_return</i> Regresar
                    </a>
                    <div id="center">
                      <?php echo e($patients->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<script>
        function search() {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: "GET",
                url: '<?php echo e(url('/menus/getPatients')); ?>',
                data: {
                    "search": document.getElementById("str").value
                },
                success: function(Response) {
                    document.getElementById("table").innerHTML = Response;
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/patients/index.blade.php ENDPATH**/ ?>