<div class="container">
    <div class="section text-center">
            <h2 class="title">Pacientes </h2>

            <div class="team">
                <div class="row">
                    <table class="table">
                        <thead>
                            <tr>
                                <!-- <th class="text-center">#</th> -->
                                <th>Nombre</th>
                                <th>Nombre de usuario</th>
                                <th>Menú actual</th>
                                <th class="text-right">Acciones</th>
                            </tr>
                        </thead>
                            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <tr>
                                    <!-- <td class="text-center"><?php echo e($patient->id); ?></td> -->
                                    <td><?php echo e($patient->fullname); ?></td>
                                    <td><?php echo e($patient->username); ?></td>
                                    <td><?php echo e($patient->description); ?></td>
                                    <td class="td-actions text-right">
                                        <a href="<?php echo e(url("/rutinas/patientMassive/$patient->id")); ?>" class="btn btn-primary">
                                            <i class="material-icons">add_box</i>
                                        </a>
                                        <a href="<?php echo e(url('/rutinas/patient/'.$patient->id.'')); ?>" rel="tooltip" title="Ver" class="btn btn-success">
                                            <i class="material-icons">info</i>
                                        </a>
                                    </td>
                                </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
<?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/routines/tableAll_sub.blade.php ENDPATH**/ ?>