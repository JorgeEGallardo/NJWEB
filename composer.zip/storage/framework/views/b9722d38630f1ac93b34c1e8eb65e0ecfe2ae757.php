
    <div class="section text-center">
      <h2 class="title">Catálogo </h2>
      <div class="team" style="margin-left:5%;margin-right:5%">
        <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th>Descripción</th>
                    <th>Menu</th>
                    <th>Receta</th>
                    <th class="text-right">Actions</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($menu->description); ?></td>
                    <td style="width:30%; height:25%"><textarea style="margin:0px; padding:0px; height:7em!important;width:100%"><?php echo e($menu->menu); ?></textarea>
                    </td>
                    <td style="width:30%; height:25%"><textarea style="margin:0px; padding:0px; height:7em!important;width:100%"><?php echo e($menu->recipes); ?></textarea>
                    </td>
                    <td class="td-actions text-right">
                      <form method="post" action="<?php echo e(url('/menus/patient/'.$menu->id).'85'.$name); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                    <a href="<?php echo e(url('/menus/massiveAsign/'.$menu->id.'85'.$id)); ?>" rel="tooltip" title="Elegir este menú" class="btn btn-success">
                            <i class="material-icons">add_box</i>
                        </a>
                        <button type="submit" rel="tooltip" title="eliminar menu" class="btn btn-danger">
                            <i class="material-icons">close</i>
                        </button>
                      </form>
                    </td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

        <?php echo e($catalog->links()); ?>



      </div>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/menus/table_sub.blade.php ENDPATH**/ ?>