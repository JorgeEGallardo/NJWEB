<?php $__env->startSection('body-class','profile-page sidebar-collapse'); ?>
<?php $__env->startSection('title', 'Documentos'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header header-filter" data-parallax="true" style="background-image: url('/img/cover-index.png')">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h1 class="title">Adara wellness & spa</h1>
        <h4>Sistema de administracion de WellnessPal</h4>
      </div>
    </div>
  </div>
</div>
<div class="main main-raised">
  <div class="container">
    <div class="section text-center">

    <h2 class="title">Archivos de <?php echo e($name); ?> </h2>
        <div class="team">
            <div class="row">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="mdb-lightbox">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure class="col-md-4" style="float:left">
                        <a href='<?php echo e(url("deleteimg/$image->id")); ?>'' rel="tooltip" title="Eliminar" class="btn btn-danger" style="float:right;margin-bottom:-7%">
                                        x
                                    </a>
                                <a target="_blank" href=' <?php echo e($domain.$image->path); ?>' data-size="1600x1067">
                            <img alt="picture" src='<?php echo e($domain.$image->path); ?>' class="img-fluid">
                        </a>
                    </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        
        <h2>Documentos</h2>
        <div>
            <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width:30%;height:100%; margin:5%; float:left">
                    <a href='<?php echo e(url("deletedoc/$document->id")); ?>'' rel="tooltip" title="Eliminar" class="btn btn-danger" style="float:right; width:10%;margin-bottom:-7%;margin-left:80%">
                        x
                    </a>
                    <img class="card-img-top" src="<?php echo e(url('img/document.png')); ?>" alt="Card image" style="width:80%; margin:10%   ">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e($document->title); ?></h4>
                        <p class="card-text">Tamaño: <?php echo e($document->size); ?><br> Creado el: <?php echo e($document->created_at); ?></p>
                        <a href="<?php echo e($domain.$document->path); ?>" class="btn btn-primary stretched-link">Descargar</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

            <div class="container"> 
                <form action="<?php echo e(route('uploadfile')); ?>" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="patient" value=<?php echo e($id); ?>>
                    <input type="file" name="file" id="" class="form-control inputFileVisible">
                    <span class="help-block text-danger"><?php echo e($errors->first('file')); ?></span>
                    <div class="form-group form-file-upload form-file-multiple">
                        <div class="input-group">
                            <input type="hidden" value="Paciente <?php echo e($name); ?>" name="title" id="caption" class="form-control"></textarea>
                            <span class="help-block text-danger"><?php echo e($errors->first('title')); ?></span>
                        </div>
                        

                    </div>
                    <button class="btn btn-primary">Subir una nueva imagen</button>
                </form>

                <form action="<?php echo e(route('uploaddoc')); ?>" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="patient" value=<?php echo e($id); ?>>
                    <input type="file" name="file" id="" class="form-control inputFileVisible">
                    <span class="help-block text-danger"><?php echo e($errors->first('file')); ?></span>
                    <div class="form-group form-file-upload form-file-multiple">
                        <div class="input-grup">
                            <input textarea name="title" id="caption" class="form-control" placeholder="Titulo del documento" required></textarea>
                            <span class="help-block text-danger"><?php echo e($errors->first('title')); ?></span>
                        </div>
                    </div>
                    <button class="btn btn-primary">Subir un documento nuevo</button>
                </form>

    </div>
  </div>
  <a href ="<?php echo e(url('/patient')); ?>"class="btn btn-success btn-round">
      <i class="material-icons">keyboard_return</i> Regresar
    </a>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/patients/atach.blade.php ENDPATH**/ ?>