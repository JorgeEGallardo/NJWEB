<?php $__env->startSection('body-class','profile-page sidebar-collapse'); ?>
<?php $__env->startSection('title', 'Edicion de paciente'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header header-filter" data-parallax="true" style="background-image: url('/img/cover-index.png')">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h1 class="title">Adara wellness & spa</h1>
        <h4>Sistema de administracion de WellnessPal</h4>
      </div>
    </div>
  </div>
</div>
<div class="main main-raised">
  <div class="container">
    <div class="section text-center">
      <h2 class="title">Editar paciente</h2>
      <form method="post" action="<?php echo e(url('/patient/'.$patient->id.'/edit')); ?>">
       <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-sm-6">
            <div class="form-group label-floating">
              <label class="control-label">Usuario</label>
              <input type="texto" class="form-control" name="username" value ="<?php echo e($patient->username); ?>" required>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group label-floating">
              <label class="control-label">Contraseña</label>
              <input type="texto" class="form-control" name="password" value ="<?php echo e($patient->password); ?>" required>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group label-floating">
              <label class="control-label">Nombre completo</label>
              <input type="texto" class="form-control" name="name" value ="<?php echo e($patient->fullname); ?>" required>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="form-group label-floating">

              <label class="control-label">Observaciónes</label>
              <input type="texto" class="form-control" name="note" value ="<?php echo e($patient->note); ?>" required>
            </div>
          </div>
          <div class="col-sm-6">
              <div class="form-group label-floating">
                <label class="control-label">Descripcion</label>
                <input type="texto" class="form-control" name="description" value ="<?php echo e($patient->description); ?>" required>
              </div>
            </div>
          </div>
        <button type="submit" class="btn btn-success">Guardar</button>
        <a href="<?php echo e(url ('/patient')); ?>" class="btn btn-danger"> Cancelar </a>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/patients/edit.blade.php ENDPATH**/ ?>