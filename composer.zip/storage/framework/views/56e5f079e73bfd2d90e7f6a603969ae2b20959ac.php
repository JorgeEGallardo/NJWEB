<?php $__env->startSection('body-class','profile-page sidebar-collapse'); ?>
<?php $__env->startSection('title', 'Creacion de recetas'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-header header-filter" data-parallax="true" style="background-image: url('/img/cover-index.png')">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1 class="title">Adara wellness & spa</h1>
                <h4>Sistema de administracion de WellnessPal</h4>
            </div>
        </div>
    </div>
</div>
<div class="main main-raised">
    <div class="container">
        <div class="section text-center">
            <h2 class="title">Añadir rutina</h2>
            <form method="post" action="<?php echo e(url('/rutinas/patientMassive')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group col-sm-12">
                        <label>Paciente</label>
                        <select name="patient_id" class="form-control selectpicker" data-style="btn btn-link" id="exampleFormControlSelect1">
                            <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                        </select>
                    </div>
                <div class="form-group col-sm-12">
                    <label>Rutinas</label>
                    <textarea id="xd" onInput="awa();" name="raw" class="form-control" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Cargar rutinas</button>
                <a href="<?php echo e(url ('/rutinas')); ?>" class="btn btn-danger"> Cancelar </a>
            </form>
        </div>
        <div id="auch">

        </div>
    </div>
</div>
<script>
    function awa() {
        $.ajax({
            type: "POST",
            url: '<?php echo e(url('/rutinas/temp')); ?>',
            data: $("form").serialize(),
            success: function(Response) {
                document.getElementById("auch").innerHTML = Response;
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ht\Erk\resources\views/routines/massive.blade.php ENDPATH**/ ?>